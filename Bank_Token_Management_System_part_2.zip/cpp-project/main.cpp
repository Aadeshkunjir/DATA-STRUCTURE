#include <iostream> 
using namespace std; 

int main() { 
    int stack[5]; 
    int top = -1; 
    
    cout << "Enter 5 served customer token numbers:\n"; 
    
    // Fixed: Input statement is now inside the loop to push 5 elements onto the stack
    for (int i = 0; i < 5; i++) { 
        top++; 
        cin >> stack[top]; 
    } 
    
    cout << "\n===== SERVICE HISTORY =====\n"; 
    
    // Pops and displays the elements in Last-In, First-Out (LIFO) order
    while (top >= 0) { 
        cout << "Token: " << stack[top] << endl; 
        top--; 
    } 
    
    return 0; 
}
